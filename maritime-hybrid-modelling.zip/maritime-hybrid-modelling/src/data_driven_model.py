"""
data_driven_model.py
====================

Pure data-driven baseline using gradient boosting (XGBoost). Provided for
comparison against (a) the physics-only baseline and (b) the hybrid model.

The role of this module in the methodological demonstration is to show that
a flexible black-box learner, given the same features, can fit the data
well in-sample but exhibits typical data-driven weaknesses: extrapolation
risk and loss of physical interpretability. The hybrid model that follows
inherits the strengths of both.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from xgboost import XGBRegressor


DATA_DRIVEN_FEATURES = [
    "speed_kn", "draft_m", "displacement_t",
    "wave_height_m", "wind_speed_mps", "rel_dir_deg", "current_mps",
]


class DataDrivenModel:
    """XGBoost regressor predicting shaft power directly from operating
    conditions. No physics is embedded."""

    def __init__(self,
                 n_estimators: int = 400,
                 max_depth: int = 5,
                 learning_rate: float = 0.05,
                 random_state: int = 0) -> None:
        self.model = XGBRegressor(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=learning_rate,
            subsample=0.9,
            colsample_bytree=0.9,
            objective="reg:squarederror",
            random_state=random_state,
            n_jobs=1,
        )

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> "DataDrivenModel":
        self.model.fit(X[DATA_DRIVEN_FEATURES].values, y)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        return self.model.predict(X[DATA_DRIVEN_FEATURES].values)


if __name__ == "__main__":
    from data_generation import build_synthetic_dataset
    from sklearn.metrics import mean_squared_error

    df = build_synthetic_dataset()
    # Use the same baseline window as the physics model
    train = df.iloc[:60]
    model = DataDrivenModel().fit(train, train["shaft_power_kw"].values)
    pred = model.predict(df)
    rmse = float(np.sqrt(mean_squared_error(df["shaft_power_kw"].values, pred)))
    print(f"Data-driven full-record RMSE (kW): {rmse:.1f}")
