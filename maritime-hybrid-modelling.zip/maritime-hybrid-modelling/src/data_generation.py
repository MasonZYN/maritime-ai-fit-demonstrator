"""
data_generation.py
==================

Synthetic vessel-operation dataset generator grounded in naval-architecture
relationships. The dataset is *clearly labelled as synthetic*: it is intended
to demonstrate methodology, not to substitute for real operational data.

Physics references used (standard naval architecture):

- Admiralty coefficient relationship:        P_shaft ~ Delta^(2/3) * V^3 / C_adm
- Holtrop & Mennen / ITTC-style added resistance from waves (simplified):
  added shaft-power term proportional to (H_w)^2 and a function of relative
  wind direction.
- ISO 19030-style speed-power reference curve concept: a clean reference
  speed-power curve plus weather and condition corrections.
- Biofouling progression modelled as a slow monotonic increase in resistance
  multiplier over time, plus a "cleaning event" reset, consistent with the
  drydocking / hull-cleaning pattern in commercial operations.

Outputs a CSV with daily-aggregated voyage data over ~24 months for one
notional handysize bulk carrier.

The synthetic generator itself is the dataset's documentation. There are no
hidden ML or shortcuts in here — every variable is produced from explicit
physics + noise, so the methodology demonstration downstream is honest.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Vessel particulars (notional handysize bulk carrier — realistic order of
# magnitude; not modelling a specific ship)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class VesselParticulars:
    name: str = "MV Synthetic Handysize"
    length_bp_m: float = 180.0          # length between perpendiculars
    breadth_m: float = 30.0
    design_draft_m: float = 10.5
    displacement_design_t: float = 45_000.0   # tonnes at design draft
    admiralty_coefficient: float = 480.0       # typical handysize range
    sfoc_g_per_kwh: float = 175.0              # specific fuel oil consumption
    mcr_kw: float = 7_500.0                    # maximum continuous rating


# ---------------------------------------------------------------------------
# Environmental & operational sampling
# ---------------------------------------------------------------------------
def _sample_environment(n_days: int, rng: np.random.Generator) -> pd.DataFrame:
    """Synthesize daily-mean weather. Distributions are deliberately broad
    so the model has to handle real-looking variability."""
    # Significant wave height (m) — Weibull-like, capped
    Hs = np.clip(rng.weibull(1.6, n_days) * 2.0, 0.2, 7.0)

    # Wind speed (m/s)
    wind_speed = np.clip(rng.weibull(2.0, n_days) * 6.0, 0.5, 22.0)

    # Relative wind/wave direction in degrees from bow (0 = head, 180 = following)
    rel_dir_deg = rng.uniform(0.0, 180.0, n_days)

    # Sea-current effect on ground speed (m/s, signed: + = following)
    current = rng.normal(0.0, 0.4, n_days)

    return pd.DataFrame({
        "wave_height_m": Hs,
        "wind_speed_mps": wind_speed,
        "rel_dir_deg": rel_dir_deg,
        "current_mps": current,
    })


def _sample_loading_and_speed(n_days: int, vessel: VesselParticulars,
                              rng: np.random.Generator) -> pd.DataFrame:
    """Synthesize loading condition and commanded speed.
    Loading affects displacement, which affects required power."""
    # Draft varies between ballast (~6 m) and laden (~design draft).
    # Voyage segments tend to be persistent — use a random walk + clipping.
    draft = np.zeros(n_days)
    draft[0] = rng.uniform(6.5, vessel.design_draft_m)
    for i in range(1, n_days):
        draft[i] = np.clip(draft[i - 1] + rng.normal(0, 0.15),
                           6.0, vessel.design_draft_m + 0.3)
    # Occasional port calls flip the loading state
    flip_mask = rng.uniform(0, 1, n_days) < 0.02
    for i in np.where(flip_mask)[0]:
        draft[i:] = rng.uniform(6.5, vessel.design_draft_m)

    # Displacement scales roughly with draft^1.0 for a box-like coefficient;
    # we use a simple linear scaling for synthetic purposes.
    displacement = vessel.displacement_design_t * (draft / vessel.design_draft_m)

    # Commanded speed through water (knots): typically 11 – 14 kn for handysize.
    speed_kn = np.clip(rng.normal(12.5, 1.0, n_days), 9.5, 14.5)

    return pd.DataFrame({
        "draft_m": draft,
        "displacement_t": displacement,
        "speed_kn": speed_kn,
    })


# ---------------------------------------------------------------------------
# Physics: required shaft power
# ---------------------------------------------------------------------------
def _admiralty_power_kw(displacement_t: np.ndarray, speed_kn: np.ndarray,
                        C_adm: float) -> np.ndarray:
    """Admiralty-style clean-hull power demand:
        P = Delta^(2/3) * V^3 / C_adm
    with V in knots and Delta in tonnes; this is a standard first-order
    approximation suitable for performance trending."""
    return (displacement_t ** (2.0 / 3.0)) * (speed_kn ** 3) / C_adm


def _added_power_weather_kw(P_clean_kw: np.ndarray,
                            wave_height_m: np.ndarray,
                            wind_speed_mps: np.ndarray,
                            rel_dir_deg: np.ndarray) -> np.ndarray:
    """Simplified added power due to weather. Magnitudes broadly consistent
    with ISO 19030 expectation that head seas at Hs ~ 3 m add ~10-25%
    to clean-hull power demand for a vessel of this size."""
    # Direction factor: head seas (0 deg) cost most; following seas (180) least
    dir_factor = (np.cos(np.deg2rad(rel_dir_deg)) + 1.0) / 2.0  # 1 at head, 0 at following
    # Wave-added power: roughly proportional to Hs^2
    wave_added = 0.045 * (wave_height_m ** 2) * dir_factor * P_clean_kw
    # Wind-added power: proportional to V_wind^2 (simplified)
    wind_added = 0.0008 * (wind_speed_mps ** 2) * dir_factor * P_clean_kw
    return wave_added + wind_added


def _fouling_multiplier(day_index: np.ndarray,
                        cleaning_day: int = 540) -> np.ndarray:
    """Biofouling progression: monotonic resistance increase over time,
    reset at a hull-cleaning event.

    Rough magnitudes:
      - 0 -> ~12 % power penalty over ~18 months in service without cleaning
      - Reset to baseline after cleaning
    Consistent with published ranges in ISO 19030 / industry reports.
    """
    days_since_clean = np.where(day_index < cleaning_day,
                                day_index,
                                day_index - cleaning_day)
    # Logistic-ish growth, capped near 12 %
    growth = 0.12 * (1.0 - np.exp(-days_since_clean / 240.0))
    return 1.0 + growth


# ---------------------------------------------------------------------------
# Top-level builder
# ---------------------------------------------------------------------------
def build_synthetic_dataset(n_days: int = 720,
                            random_seed: int = 42,
                            cleaning_day: int = 540,
                            vessel: VesselParticulars = VesselParticulars()
                            ) -> pd.DataFrame:
    """Construct a daily-resolution synthetic vessel operation dataset."""
    rng = np.random.default_rng(random_seed)

    days = np.arange(n_days)
    env = _sample_environment(n_days, rng)
    load = _sample_loading_and_speed(n_days, vessel, rng)

    P_clean = _admiralty_power_kw(load["displacement_t"].values,
                                  load["speed_kn"].values,
                                  vessel.admiralty_coefficient)

    P_weather = _added_power_weather_kw(P_clean,
                                        env["wave_height_m"].values,
                                        env["wind_speed_mps"].values,
                                        env["rel_dir_deg"].values)

    foul_mult = _fouling_multiplier(days, cleaning_day=cleaning_day)

    # True shaft power demand with all effects
    P_true = (P_clean + P_weather) * foul_mult

    # Measurement noise (sensor + sea-state randomness)
    noise = rng.normal(0.0, 0.03 * P_true)
    P_measured = np.clip(P_true + noise, 100.0, vessel.mcr_kw)

    # Fuel mass flow (tonnes/day) from SFOC
    fuel_t_per_day = P_measured * 24.0 * (vessel.sfoc_g_per_kwh / 1e6)

    df = pd.DataFrame({
        "day": days,
        "speed_kn": load["speed_kn"],
        "draft_m": load["draft_m"],
        "displacement_t": load["displacement_t"],
        "wave_height_m": env["wave_height_m"],
        "wind_speed_mps": env["wind_speed_mps"],
        "rel_dir_deg": env["rel_dir_deg"],
        "current_mps": env["current_mps"],
        "shaft_power_kw": P_measured,
        "fuel_consumption_tpd": fuel_t_per_day,
        # Ground-truth quantities (used ONLY for evaluation / plots,
        # never as input features to the models below)
        "_true_clean_power_kw": P_clean,
        "_true_weather_added_kw": P_weather,
        "_true_fouling_multiplier": foul_mult,
    })

    return df


if __name__ == "__main__":
    df = build_synthetic_dataset()
    print(df.head())
    print(f"\nRows: {len(df)}")
    print(f"Power range (kW): {df['shaft_power_kw'].min():.0f} – "
          f"{df['shaft_power_kw'].max():.0f}")
    print(f"Fuel range (t/day): {df['fuel_consumption_tpd'].min():.2f} – "
          f"{df['fuel_consumption_tpd'].max():.2f}")
