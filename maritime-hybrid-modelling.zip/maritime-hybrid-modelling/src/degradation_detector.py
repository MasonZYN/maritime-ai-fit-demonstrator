"""
degradation_detector.py
=======================

Performance-degradation detector for hull condition (biofouling proxy).

Concept
-------
For a hybrid model fit on a clean-hull baseline window:

    P_measured = P_phys + ML_residual_baseline + epsilon_t

After deployment, if the hull condition degrades (biofouling), the actual
measurement drifts upward relative to the baseline prediction:

    P_measured(t) = P_phys + ML_residual_baseline + DRIFT(t) + noise

The detector tracks DRIFT(t) by computing a rolling, weather- and load-
normalised excess-power signal:

    excess(t) = ( P_measured(t) - P_hybrid_baseline(t) ) / P_phys(t)

A simple EWMA smooths short-term variability, and a CUSUM-style alarm flags
sustained positive drift, which is the operational signature of progressive
fouling. After a cleaning event, the signal resets.

This module exposes:
- compute_excess_power_signal()
- ewma()
- cusum_alarm()
"""

from __future__ import annotations
import numpy as np
import pandas as pd


def compute_excess_power_signal(measured_kw: np.ndarray,
                                hybrid_baseline_kw: np.ndarray,
                                physics_kw: np.ndarray) -> np.ndarray:
    """Per-day fractional excess shaft power, normalised by the physics
    reference. Dimensionless. Centred near zero on clean hull, drifts
    positive as fouling progresses."""
    eps = 1e-6
    return (measured_kw - hybrid_baseline_kw) / np.maximum(physics_kw, eps)


def ewma(x: np.ndarray, alpha: float = 0.05) -> np.ndarray:
    """Exponentially weighted moving average; alpha small => heavy smoothing."""
    out = np.zeros_like(x, dtype=float)
    out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = alpha * x[i] + (1.0 - alpha) * out[i - 1]
    return out


def cusum_alarm(signal: np.ndarray,
                threshold: float = 0.03,
                drift_offset: float = 0.0) -> np.ndarray:
    """One-sided CUSUM on a centred, smoothed signal. Returns a boolean
    array of the same length, True from the first day the CUSUM crosses
    the threshold until the signal returns below zero (cleaning reset).

    Parameters
    ----------
    signal : array
        Smoothed excess-power signal (fraction).
    threshold : float
        Cumulative sum threshold above which an alarm is raised.
    drift_offset : float
        Reference level (typically zero or small positive); the CUSUM
        accumulates (signal - drift_offset).
    """
    n = len(signal)
    cusum = np.zeros(n)
    alarms = np.zeros(n, dtype=bool)
    s = 0.0
    alarm_state = False
    for i in range(n):
        s = max(0.0, s + (signal[i] - drift_offset))
        cusum[i] = s
        if s > threshold:
            alarm_state = True
        if signal[i] < 0:
            # reset on negative excursion (e.g., after cleaning)
            s = 0.0
            alarm_state = False
        alarms[i] = alarm_state
    return alarms


if __name__ == "__main__":
    from data_generation import build_synthetic_dataset
    from hybrid_model import HybridModel
    from physics_model import PHYSICS_FEATURES

    df = build_synthetic_dataset()
    train = df.iloc[:60]
    hybrid = HybridModel().fit(train, train["shaft_power_kw"].values)

    y_hybrid = hybrid.predict(df)
    y_phys = hybrid.physics.predict(df[PHYSICS_FEATURES])

    excess = compute_excess_power_signal(df["shaft_power_kw"].values,
                                         y_hybrid, y_phys)
    excess_smooth = ewma(excess, alpha=0.03)
    alarms = cusum_alarm(excess_smooth, threshold=0.5, drift_offset=0.005)

    print(f"Excess signal range:  {excess.min():.3f} – {excess.max():.3f}")
    print(f"First alarm day:      {int(np.argmax(alarms)) if alarms.any() else 'no alarm'}")
    print(f"Days under alarm:     {int(alarms.sum())} / {len(alarms)}")
