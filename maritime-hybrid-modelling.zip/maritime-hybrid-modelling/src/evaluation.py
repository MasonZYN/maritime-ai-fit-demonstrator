"""
evaluation.py
=============

Run the full comparison: physics-only, data-driven, hybrid. Compute
standard regression metrics, plot predicted vs measured, residual time
series, model decomposition, and the degradation-detection signal with
alarms overlaid on the ground-truth fouling progression.

All figures are saved to ../figures/.
"""

from __future__ import annotations
import os
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

from data_generation import build_synthetic_dataset
from physics_model import PhysicsBaseline, PHYSICS_FEATURES
from data_driven_model import DataDrivenModel, DATA_DRIVEN_FEATURES
from hybrid_model import HybridModel
from degradation_detector import (
    compute_excess_power_signal, ewma, cusum_alarm,
)


FIG_DIR = Path(__file__).resolve().parent.parent / "figures"
FIG_DIR.mkdir(exist_ok=True)


# ----------------------------------------------------------------------
# Metrics
# ----------------------------------------------------------------------
def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    return {
        "RMSE_kW": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "MAE_kW":  float(mean_absolute_error(y_true, y_pred)),
        "R2":      float(r2_score(y_true, y_pred)),
        "MAPE_%":  float(np.mean(np.abs((y_true - y_pred) / np.maximum(y_true, 1.0))) * 100.0),
    }


# ----------------------------------------------------------------------
# Plotting helpers
# ----------------------------------------------------------------------
def _style():
    plt.rcParams.update({
        "figure.dpi": 120,
        "savefig.dpi": 150,
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
        "legend.fontsize": 9,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.25,
    })


def plot_dataset_overview(df: pd.DataFrame) -> None:
    fig, axes = plt.subplots(4, 1, figsize=(9, 8), sharex=True)
    axes[0].plot(df["day"], df["shaft_power_kw"], color="#1f3864", lw=0.8)
    axes[0].set_ylabel("Shaft power (kW)")
    axes[0].set_title("Synthetic vessel operation dataset (24 months, 1-day resolution)")

    axes[1].plot(df["day"], df["speed_kn"], color="#7f7f7f", lw=0.8)
    axes[1].set_ylabel("Speed (kn)")

    axes[2].plot(df["day"], df["wave_height_m"], color="#2c7fb8", lw=0.8)
    axes[2].set_ylabel("Hs (m)")

    axes[3].plot(df["day"], df["_true_fouling_multiplier"], color="#c0504d", lw=1.2)
    axes[3].axvline(540, ls="--", color="black", lw=0.8, alpha=0.5)
    axes[3].text(545, 1.005, "hull cleaning", fontsize=8)
    axes[3].set_ylabel("Fouling factor")
    axes[3].set_xlabel("Day")

    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig_01_dataset_overview.png")
    plt.close(fig)


def plot_predicted_vs_measured(y_true, preds: dict) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.6), sharey=True)
    colors = {"Physics": "#1f3864", "Data-driven": "#7f7f7f", "Hybrid": "#c0504d"}
    for ax, (name, yp) in zip(axes, preds.items()):
        ax.scatter(y_true, yp, s=6, alpha=0.45, color=colors[name])
        lo, hi = float(min(y_true.min(), yp.min())), float(max(y_true.max(), yp.max()))
        ax.plot([lo, hi], [lo, hi], "k--", lw=0.8, alpha=0.7)
        ax.set_xlabel("Measured shaft power (kW)")
        ax.set_title(name)
    axes[0].set_ylabel("Predicted shaft power (kW)")
    fig.suptitle("Predicted vs. measured shaft power — full operating record", y=1.02)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig_02_predicted_vs_measured.png", bbox_inches="tight")
    plt.close(fig)


def plot_residual_timeseries(df: pd.DataFrame, preds: dict) -> None:
    fig, ax = plt.subplots(figsize=(9, 3.6))
    colors = {"Physics": "#1f3864", "Data-driven": "#7f7f7f", "Hybrid": "#c0504d"}
    for name, yp in preds.items():
        ax.plot(df["day"], df["shaft_power_kw"].values - yp,
                label=name, lw=0.6, alpha=0.85, color=colors[name])
    ax.axvline(540, ls="--", color="black", lw=0.8, alpha=0.4)
    ax.text(545, ax.get_ylim()[1] * 0.85, "hull cleaning", fontsize=8)
    ax.axhline(0, color="black", lw=0.5, alpha=0.5)
    ax.set_xlabel("Day")
    ax.set_ylabel("Residual: measured − predicted (kW)")
    ax.set_title("Model residuals over time — drift reveals hull-condition degradation")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig_03_residual_timeseries.png")
    plt.close(fig)


def plot_hybrid_decomposition(df, hybrid: HybridModel) -> None:
    y_phys, y_resid = hybrid.predict_components(df)
    fig, ax = plt.subplots(figsize=(9, 3.6))
    ax.plot(df["day"], y_phys, lw=0.7, color="#1f3864",
            label="Physics component")
    ax.plot(df["day"], y_resid, lw=0.7, color="#c0504d",
            label="ML residual component")
    ax.axhline(0, color="black", lw=0.5, alpha=0.5)
    ax.set_xlabel("Day")
    ax.set_ylabel("Power contribution (kW)")
    ax.set_title("Hybrid model decomposition — interpretable physics + data-driven correction")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig_04_hybrid_decomposition.png")
    plt.close(fig)


def plot_degradation_detection(df, excess, excess_smooth, alarms) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(9, 5.4), sharex=True)

    axes[0].plot(df["day"], excess, color="#7f7f7f", lw=0.4, alpha=0.7,
                 label="Daily excess-power signal")
    axes[0].plot(df["day"], excess_smooth, color="#c0504d", lw=1.2,
                 label="EWMA-smoothed signal")
    axes[0].axhline(0, color="black", lw=0.5, alpha=0.5)
    axes[0].axvline(540, ls="--", color="black", lw=0.8, alpha=0.4)
    axes[0].text(545, axes[0].get_ylim()[1] * 0.85, "hull cleaning", fontsize=8)
    axes[0].set_ylabel("Excess power (fraction)")
    axes[0].set_title("Hull-condition health signal")
    axes[0].legend(loc="upper left")

    axes[1].plot(df["day"], df["_true_fouling_multiplier"] - 1.0,
                 color="#1f3864", lw=1.0, label="Ground-truth fouling fraction")
    # shade alarm regions
    alarm_changes = np.diff(np.r_[0, alarms.astype(int), 0])
    starts = np.where(alarm_changes == 1)[0]
    ends   = np.where(alarm_changes == -1)[0]
    for s, e in zip(starts, ends):
        axes[1].axvspan(s, e, color="#c0504d", alpha=0.18,
                        label="CUSUM alarm" if s == starts[0] else None)
    axes[1].axvline(540, ls="--", color="black", lw=0.8, alpha=0.4)
    axes[1].set_xlabel("Day")
    axes[1].set_ylabel("Ground-truth fouling")
    axes[1].set_title("Detection alarms vs. ground-truth fouling progression")
    axes[1].legend(loc="upper left")

    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig_05_degradation_detection.png")
    plt.close(fig)


def plot_metrics_bar(metrics_dict: dict) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.2))
    keys = ["RMSE_kW", "MAE_kW", "MAPE_%"]
    titles = ["RMSE (kW)", "MAE (kW)", "MAPE (%)"]
    colors = ["#1f3864", "#7f7f7f", "#c0504d"]
    names = list(metrics_dict.keys())
    for ax, k, t in zip(axes, keys, titles):
        vals = [metrics_dict[n][k] for n in names]
        ax.bar(names, vals, color=colors)
        ax.set_title(t)
        for i, v in enumerate(vals):
            ax.text(i, v, f"{v:.1f}", ha="center", va="bottom", fontsize=9)
    fig.suptitle("Model comparison on full operating record", y=1.02)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig_06_metrics_comparison.png", bbox_inches="tight")
    plt.close(fig)


# ----------------------------------------------------------------------
# Main pipeline
# ----------------------------------------------------------------------
def run_pipeline() -> dict:
    _style()
    df = build_synthetic_dataset(n_days=720, cleaning_day=540, random_seed=42)
    plot_dataset_overview(df)

    # Train window: first 90 days (clean-hull, broad weather mix)
    train = df.iloc[:90]
    y_true = df["shaft_power_kw"].values

    physics_only = PhysicsBaseline().fit(train[PHYSICS_FEATURES],
                                         train["shaft_power_kw"].values)
    data_driven = DataDrivenModel().fit(train, train["shaft_power_kw"].values)
    hybrid = HybridModel().fit(train, train["shaft_power_kw"].values)

    preds = {
        "Physics":      physics_only.predict(df[PHYSICS_FEATURES]),
        "Data-driven":  data_driven.predict(df),
        "Hybrid":       hybrid.predict(df),
    }
    metrics = {name: regression_metrics(y_true, yp) for name, yp in preds.items()}

    print("\nModel comparison (full record, 720 days)")
    print("-" * 56)
    print(f"{'Model':<14}{'RMSE':>10}{'MAE':>10}{'R2':>10}{'MAPE %':>10}")
    for name, m in metrics.items():
        print(f"{name:<14}{m['RMSE_kW']:>10.1f}{m['MAE_kW']:>10.1f}"
              f"{m['R2']:>10.3f}{m['MAPE_%']:>10.1f}")

    plot_predicted_vs_measured(y_true, preds)
    plot_residual_timeseries(df, preds)
    plot_hybrid_decomposition(df, hybrid)
    plot_metrics_bar(metrics)

    # Degradation detection from hybrid model
    y_phys = hybrid.physics.predict(df[PHYSICS_FEATURES])
    excess = compute_excess_power_signal(y_true, preds["Hybrid"], y_phys)
    excess_smooth = ewma(excess, alpha=0.03)
    alarms = cusum_alarm(excess_smooth, threshold=0.6, drift_offset=0.005)
    plot_degradation_detection(df, excess, excess_smooth, alarms)

    first_alarm = int(np.argmax(alarms)) if alarms.any() else -1
    print("\nDegradation detection")
    print("-" * 56)
    print(f"First sustained alarm: day {first_alarm}")
    print(f"Cleaning event:        day 540 (ground truth)")
    print(f"Days under alarm:      {int(alarms.sum())} / {len(alarms)}")

    # Save full metrics + a small CSV summary for the report
    summary = pd.DataFrame(metrics).T
    summary.to_csv(FIG_DIR.parent / "report" / "metrics_summary.csv")
    return {
        "metrics": metrics,
        "first_alarm_day": first_alarm,
        "physics_params": physics_only.params,
    }


if __name__ == "__main__":
    run_pipeline()
