"""
hybrid_model.py
===============

Hybrid physics-AI model: physics baseline + ML residual learner.

Approach
--------
1. Fit a physics baseline P_phys(x) on a clean-hull training window.
2. Compute residual r = P_measured - P_phys for each sample.
3. Train an ML model (XGBoost) to predict the residual from the operating
   features.
4. Final prediction:  P_hybrid(x) = P_phys(x) + ML_residual(x).

Why this matters
----------------
- The physics model carries domain knowledge (units, monotonicity in speed
  and displacement, weather sensitivity). It generalises and extrapolates
  reliably.
- The residual learner picks up whatever the physics model cannot explain:
  un-modelled drag terms, sensor biases, slow drifts. Crucially, the
  residual is a clean signal for performance degradation monitoring.
- The model is interpretable component-wise: any unusual prediction can be
  decomposed into "what the physics expected" and "what the ML adjusted".

This is the standard "physics-informed residual learning" pattern used in
the hybrid-modelling literature; the version here is deliberately simple
so the demonstration is easy to follow.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from xgboost import XGBRegressor

from physics_model import PhysicsBaseline, PHYSICS_FEATURES


HYBRID_RESIDUAL_FEATURES = [
    "speed_kn", "draft_m", "displacement_t",
    "wave_height_m", "wind_speed_mps", "rel_dir_deg",
]


class HybridModel:
    """Physics baseline + residual learner."""

    def __init__(self,
                 n_estimators: int = 300,
                 max_depth: int = 4,
                 learning_rate: float = 0.05,
                 random_state: int = 0) -> None:
        self.physics = PhysicsBaseline()
        self.residual = XGBRegressor(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=learning_rate,
            subsample=0.9,
            colsample_bytree=0.9,
            objective="reg:squarederror",
            random_state=random_state,
            n_jobs=1,
        )

    def fit(self, X_train: pd.DataFrame, y_train: np.ndarray) -> "HybridModel":
        # Step 1: fit physics on the same training window
        self.physics.fit(X_train[PHYSICS_FEATURES], y_train)

        # Step 2: residuals on the training window
        y_phys = self.physics.predict(X_train[PHYSICS_FEATURES])
        resid = y_train - y_phys

        # Step 3: ML on the residuals
        self.residual.fit(X_train[HYBRID_RESIDUAL_FEATURES].values, resid)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        y_phys = self.physics.predict(X[PHYSICS_FEATURES])
        y_resid = self.residual.predict(X[HYBRID_RESIDUAL_FEATURES].values)
        return y_phys + y_resid

    def predict_components(self, X: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        """Return (physics_part, residual_part) separately for interpretability."""
        y_phys = self.physics.predict(X[PHYSICS_FEATURES])
        y_resid = self.residual.predict(X[HYBRID_RESIDUAL_FEATURES].values)
        return y_phys, y_resid


if __name__ == "__main__":
    from data_generation import build_synthetic_dataset
    from sklearn.metrics import mean_squared_error

    df = build_synthetic_dataset()
    train = df.iloc[:60]
    hybrid = HybridModel().fit(train, train["shaft_power_kw"].values)

    pred = hybrid.predict(df)
    rmse = float(np.sqrt(mean_squared_error(df["shaft_power_kw"].values, pred)))
    print(f"Hybrid full-record RMSE (kW): {rmse:.1f}")
