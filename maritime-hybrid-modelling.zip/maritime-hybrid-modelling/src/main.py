"""
main.py
=======

Single entry point. Runs the full pipeline:
  1. Generate synthetic dataset
  2. Fit physics, data-driven, and hybrid models on the clean-hull baseline
  3. Evaluate on the full record
  4. Run the degradation detector on the hybrid residual
  5. Produce all plots and a metrics summary

Usage:
    python -m src.main
or, from the src/ directory:
    python main.py
"""

from evaluation import run_pipeline


if __name__ == "__main__":
    results = run_pipeline()
    print("\nPipeline complete. Figures in ../figures/, metrics in ../report/.")
