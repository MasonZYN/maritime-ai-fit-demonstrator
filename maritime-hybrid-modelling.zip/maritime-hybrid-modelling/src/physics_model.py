"""
physics_model.py
================

Physics-based baseline shaft-power model, in the spirit of ISO 19030 speed-
power reference curves with weather correction.

The model has a small number of physically meaningful parameters which are
*fitted* to a baseline (clean-hull, good-weather) period of the operational
data. After fitting on the baseline, the model is used to predict shaft
power for the full operating record. The residual between measured and
predicted is what the data-driven and hybrid models will subsequently
explain (residual learning) and what the degradation detector tracks.

Deliberately kept simple and interpretable — this is the role of the
physics component in a hybrid scheme.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from dataclasses import dataclass


@dataclass
class PhysicsParams:
    """Fitted parameters of the physics baseline."""
    C_adm: float          # admiralty coefficient
    k_wave: float         # wave-added power coefficient
    k_wind: float         # wind-added power coefficient


class PhysicsBaseline:
    """Speed-power reference model with weather corrections.

    P_predicted = Delta^(2/3) * V^3 / C_adm                       (clean hull)
                + k_wave * Hs^2 * dir_factor * P_clean             (waves)
                + k_wind * V_wind^2 * dir_factor * P_clean         (wind)

    All three coefficients are fitted on a baseline (clean-hull) subset of
    the data so the physics model is calibrated to the *specific vessel*.
    """

    def __init__(self) -> None:
        self.params: PhysicsParams | None = None

    # ------------------------------------------------------------------
    # Core formulas
    # ------------------------------------------------------------------
    @staticmethod
    def _clean_power(displacement_t: np.ndarray,
                     speed_kn: np.ndarray, C_adm: float) -> np.ndarray:
        return (displacement_t ** (2.0 / 3.0)) * (speed_kn ** 3) / C_adm

    @staticmethod
    def _dir_factor(rel_dir_deg: np.ndarray) -> np.ndarray:
        return (np.cos(np.deg2rad(rel_dir_deg)) + 1.0) / 2.0

    def _predict_components(self, X: pd.DataFrame,
                            params: PhysicsParams) -> tuple[np.ndarray, np.ndarray]:
        P_clean = self._clean_power(X["displacement_t"].values,
                                    X["speed_kn"].values, params.C_adm)
        df = self._dir_factor(X["rel_dir_deg"].values)
        P_added = (params.k_wave * (X["wave_height_m"].values ** 2) * df * P_clean
                   + params.k_wind * (X["wind_speed_mps"].values ** 2) * df * P_clean)
        return P_clean, P_added

    # ------------------------------------------------------------------
    # Fitting on baseline period
    # ------------------------------------------------------------------
    def fit(self, X_baseline: pd.DataFrame, y_baseline: np.ndarray) -> "PhysicsBaseline":
        """Fit physics parameters to a clean-hull baseline window."""

        def loss(theta: np.ndarray) -> float:
            params = PhysicsParams(C_adm=theta[0], k_wave=theta[1], k_wind=theta[2])
            P_clean, P_added = self._predict_components(X_baseline, params)
            y_pred = P_clean + P_added
            return float(np.mean((y_pred - y_baseline) ** 2))

        # Initial guesses informed by typical handysize ranges
        theta0 = np.array([450.0, 0.04, 0.0008])
        bounds = [(200.0, 800.0), (0.0, 0.2), (0.0, 0.01)]
        res = minimize(loss, theta0, method="L-BFGS-B", bounds=bounds)

        self.params = PhysicsParams(
            C_adm=float(res.x[0]),
            k_wave=float(res.x[1]),
            k_wind=float(res.x[2]),
        )
        return self

    # ------------------------------------------------------------------
    # Prediction
    # ------------------------------------------------------------------
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        if self.params is None:
            raise RuntimeError("PhysicsBaseline must be fit() before predict().")
        P_clean, P_added = self._predict_components(X, self.params)
        return P_clean + P_added


# ----------------------------------------------------------------------
# Convenience: feature subset used by the physics model
# ----------------------------------------------------------------------
PHYSICS_FEATURES = [
    "displacement_t", "speed_kn",
    "wave_height_m", "wind_speed_mps", "rel_dir_deg",
]


if __name__ == "__main__":
    from data_generation import build_synthetic_dataset

    df = build_synthetic_dataset()
    # Baseline = first 60 days, when fouling is negligible
    baseline = df.iloc[:60]
    X_base = baseline[PHYSICS_FEATURES]
    y_base = baseline["shaft_power_kw"].values

    model = PhysicsBaseline().fit(X_base, y_base)
    print(f"Fitted C_adm  = {model.params.C_adm:.2f}")
    print(f"Fitted k_wave = {model.params.k_wave:.4f}")
    print(f"Fitted k_wind = {model.params.k_wind:.5f}")

    y_pred_full = model.predict(df[PHYSICS_FEATURES])
    rmse = float(np.sqrt(np.mean((y_pred_full - df["shaft_power_kw"].values) ** 2)))
    print(f"Full-record RMSE (kW): {rmse:.1f}")
